<!-- 
  <footer class="mt-auto text-white-50">

    <p>Cover template for Ocean Blue LLC, <?php echo Date('Y'); ?>  by <a href="#" class="text-white">@mdo</a>.</p>

  </footer> -->


 <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
 <script src="<?php bloginfo('template_url'); ?>/functions.php"></script>
 <script src="https://kit.fontawesome.com/768ccd9ae9.js" crossorigin="anonymous"></script>
